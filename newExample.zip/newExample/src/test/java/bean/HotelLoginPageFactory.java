package bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelLoginPageFactory {
	WebDriver driver;
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;

	@FindBy(how=How.ID, using="userErrMsg")
	WebElement usernameError;
	
	@FindBy(how=How.ID, using="pwdErrMsg")
	WebElement passwordError;
   //using how class
	
	@FindBy(how=How.NAME, using="userPwd")
	@CacheLookup
	WebElement password;

	@FindBy(className="btn")
	@CacheLookup
	WebElement loginButton;


	public HotelLoginPageFactory(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getUsernameError() {
		return usernameError;
	}

	public void setUsernameError(WebElement usernameError) {
		this.usernameError=usernameError;
	}

	public WebElement getPasswordError() {
		return passwordError;
	}

	public void setPasswordError(WebElement passwordError) {
		this.passwordError=passwordError;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	

	public WebElement getLoginButton() {
		return loginButton;
	}


	public void setLoginButton() {
		this.loginButton.click();
	}



}
